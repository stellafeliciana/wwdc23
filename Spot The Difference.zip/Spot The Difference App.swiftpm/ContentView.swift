import SwiftUI

@available(iOS 16.0, *)
struct ContentView: View {
    //    @State var showCross = false
    //    @State var offsetSize: CGSize = .zero
    //    @State var hintOpacity = 0.0
    //    @State var popupView = false
    
    var body: some View {
        NavigationView{
            ZStack{
//                Image("startView")
//                    .resizable()
                
                NavigationLink(destination: spotView()){
                    Image("startView")
                        .resizable()
                }
                
                Text("<Tap Anywhere to Start>")
                    .offset(y:600)
                    .font(.system(size: 25))
            }
            .ignoresSafeArea()
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .navigationBarHidden(true)
    }
}

struct MyView_Previews: PreviewProvider {
    static var previews: some View {
        if #available(iOS 16.0, *) {
            ContentView()
        } else {
            Text("")
        }
    }
}

