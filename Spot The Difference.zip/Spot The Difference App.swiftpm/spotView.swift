//
//  spotView.swift
//  Spot The Difference App
//
//  Created by Stella Feliciana on 19/04/23.
//

import SwiftUI

@available(iOS 16.0, *)
struct spotView: View {
            @State var showCross = false
            @State var offsetSize: CGSize = .zero
            @State var hintOpacity = 0.0
            @State private var showingAlert = false
            
        var body: some View {
                NavigationView{
                    ZStack {
                        Image("spotBackground")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 1024)
                            .onTapGesture{
                                withAnimation {
                                    showCross.toggle()
                                }
                                
                                DispatchQueue.main
                                    .asyncAfter(deadline:
                                            .now()+1){
                                                withAnimation {
                                                    showCross.toggle()
                                                }
                                            }
                            }
                        Image("cross")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 180, height: 180)
                            .opacity(showCross ? 1 : 0)
                            .offset(offsetSize)
                        
                        Button{
                            withAnimation {
                                hintOpacity = 1
                            }
                            print ("Button Tapped")
                        }
                        label: {
                            Image("hintButton")
                                .resizable()
                                .frame(width: 150, height:150)
                        }
                        .offset(x:410 ,y:-610)
                        
                        ZStack {
                            Rectangle()
                                .ignoresSafeArea()
                                .opacity(0.3)
                            Image("hintPage")
                                .resizable()
                                .scaledToFit()
                            
                            VStack {
                                HStack{
                                    NavigationLink(destination: ContentView()){
                                        Image("okButton")
                                            .resizable()
                                            .frame(width:200)
                                    }

                                    Button{
                                        withAnimation{
                                            hintOpacity = 0
                                        }
                                    } label: {
                                        Image("noButton")
                                            .resizable()
                                            .frame(width:200)
                                    }
                                }
                                .frame(maxWidth: 200, maxHeight:200)
                                .offset(y:350)
                            }
                            
                        }
                        .opacity(hintOpacity)
                        }
                    .ignoresSafeArea()
                    }
            
                    .onTapGesture { point in
                        print(UIScreen.main.bounds.size.width)
                        print(UIScreen.main.bounds.size.height)
                        print(point.x)
                        print(point.y)
                        
                        
                        
                        // Lakukan kalkulasinya disini
                        
                        offsetSize = CGSize(width: point.x-UIScreen.main.bounds.size.width/2, height: point.y-UIScreen.main.bounds.size.height/2)
                }
                .navigationViewStyle(StackNavigationViewStyle())
                .navigationBarHidden(true)
            }
        }
 

struct spotView_Previews: PreviewProvider {
    static var previews: some View {
        if #available(iOS 16.0, *) {
            spotView()
        } else {
            // Fallback on earlier versions
        }
    }
}
